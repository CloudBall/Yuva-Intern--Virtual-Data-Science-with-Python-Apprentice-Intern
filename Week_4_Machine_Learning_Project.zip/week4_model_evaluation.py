"""
Week 4 Task: Machine Learning Model Development and Evaluation
Dataset: Wisconsin Diagnostic Breast Cancer dataset (bundled with scikit-learn)
Target: malignant = 1, benign = 0

Install:
    pip install pandas numpy matplotlib scikit-learn

Files:
    breast_cancer_diagnostic_dataset.csv
Run this script from the folder containing the CSV.
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
    confusion_matrix, ConfusionMatrixDisplay, roc_curve
)

df = pd.read_csv("breast_cancer_diagnostic_dataset.csv")
X = df.drop(columns=["malignant"])
y = df["malignant"].astype(int)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

models = {
    "Logistic Regression": Pipeline([
        ("scaler", StandardScaler()),
        ("model", LogisticRegression(max_iter=5000, random_state=42))
    ]),
    "Decision Tree": DecisionTreeClassifier(
        max_depth=4, min_samples_leaf=3, random_state=42
    )
}

rows = []
predictions = {}
for name, model in models.items():
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    prob = model.predict_proba(X_test)[:, 1]
    predictions[name] = (pred, prob)
    rows.append({
        "Model": name,
        "Accuracy": accuracy_score(y_test, pred),
        "Precision": precision_score(y_test, pred, zero_division=0),
        "Recall": recall_score(y_test, pred, zero_division=0),
        "F1-score": f1_score(y_test, pred, zero_division=0),
        "ROC-AUC": roc_auc_score(y_test, prob)
    })

metrics = pd.DataFrame(rows)
print("Test-set performance:")
print(metrics.to_string(index=False, float_format=lambda value: f"{value:.3f}"))
metrics.to_csv("model_metrics.csv", index=False)

# Visualization 1: metric comparison
metric_names = ["Accuracy", "Precision", "Recall", "F1-score", "ROC-AUC"]
positions = np.arange(len(metric_names))
width = 0.34
plt.figure(figsize=(9, 5.5))
for i, row in metrics.set_index("Model").iterrows():
    pass
for i, name in enumerate(metrics["Model"]):
    row = metrics.loc[metrics["Model"] == name].iloc[0]
    plt.bar(positions + (i - 0.5) * width, [row[m] for m in metric_names],
            width, label=name)
plt.xticks(positions, metric_names)
plt.ylim(0, 1.08)
plt.ylabel("Score")
plt.title("Classification Model Performance Comparison")
plt.legend()
plt.grid(axis="y", alpha=0.25)
plt.tight_layout()
plt.savefig("model_metrics_comparison.png", dpi=180)
plt.show()

# Visualization 2: confusion matrices
fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))
for ax, name in zip(axes, models):
    pred, _ = predictions[name]
    ConfusionMatrixDisplay(
        confusion_matrix=confusion_matrix(y_test, pred),
        display_labels=["Benign (0)", "Malignant (1)"]
    ).plot(ax=ax, colorbar=False, values_format="d")
    ax.set_title(name)
plt.suptitle("Confusion Matrices on the Held-Out Test Set")
plt.tight_layout()
plt.savefig("confusion_matrices.png", dpi=180)
plt.show()

# Visualization 3: ROC curves
plt.figure(figsize=(7.5, 5.5))
for name, (_, prob) in predictions.items():
    fpr, tpr, _ = roc_curve(y_test, prob)
    auc = roc_auc_score(y_test, prob)
    plt.plot(fpr, tpr, label=f"{name} (AUC = {auc:.3f})")
plt.plot([0, 1], [0, 1], linestyle="--", label="Chance baseline")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curves on the Held-Out Test Set")
plt.legend()
plt.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("roc_curves.png", dpi=180)
plt.show()

print("\\nImportant: this is an educational benchmark, not a clinical diagnostic tool.")
