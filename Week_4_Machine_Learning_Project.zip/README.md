# Week 4: Machine Learning Model Development and Evaluation

## Topic
Comparison of Logistic Regression and Decision Tree using the Wisconsin Diagnostic Breast Cancer benchmark dataset.

## Files
- `Week_4_Machine_Learning_Report.docx` — full report
- `week4_model_evaluation.py` — Python workflow
- `breast_cancer_diagnostic_dataset.csv` — dataset
- `model_metrics.csv` — evaluation metrics
- `model_metrics_comparison.png` — metric comparison chart
- `confusion_matrices.png` — confusion matrices
- `roc_curves.png` — ROC curves
- `submission_description.txt` — text for the submission form

## Run
Install dependencies:
```bash
pip install pandas numpy matplotlib scikit-learn
```
Run from this folder:
```bash
python week4_model_evaluation.py
```

## Important limitation
This is an educational benchmark, not a clinical diagnostic tool. Do not use these models to make medical decisions.
