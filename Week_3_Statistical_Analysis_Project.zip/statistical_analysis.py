"""
Week 3 Task: Statistical Analysis and Hypothesis Testing in Python
Topic: Relationship between daily study hours and exam scores

Dataset note:
The included CSV is a reproducible synthetic dataset created for this project.
It is not real student data. Replace it with a properly sourced public dataset
if your internship evaluator requires real-world observations.
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

DATA_FILE = "study_hours_exam_scores.csv"
df = pd.read_csv(DATA_FILE)

x = df["Study_Hours_Per_Day"]
y = df["Exam_Score"]

print("DESCRIPTIVE STATISTICS")
print(df[["Study_Hours_Per_Day", "Exam_Score"]].describe().round(3))

# Hypotheses for Pearson correlation
# H0: population correlation rho = 0
# H1: population correlation rho != 0
r, p = stats.pearsonr(x, y)
n = len(df)
t_stat = r * np.sqrt((n - 2) / (1 - r**2))
ci_low, ci_high = stats.bootstrap(
    (x.to_numpy(), y.to_numpy()),
    statistic=lambda a, b: np.corrcoef(a, b)[0, 1],
    paired=True, confidence_level=0.95, n_resamples=5000,
    method="percentile", random_state=np.random.default_rng(42)
).confidence_interval

slope, intercept, r_value, p_reg, std_err = stats.linregress(x, y)

print("\\nPEARSON CORRELATION TEST")
print(f"n = {n}")
print(f"Pearson r = {r:.4f}")
print(f"t({n-2}) = {t_stat:.4f}")
print(f"two-tailed p-value = {p:.6g}")
print(f"95% bootstrap CI for r = [{ci_low:.4f}, {ci_high:.4f}]")
print("\\nSIMPLE LINEAR REGRESSION")
print(f"Exam score = {intercept:.3f} + {slope:.3f} * study hours")
print(f"R-squared = {r_value**2:.4f}")
print(f"Regression p-value = {p_reg:.6g}")

alpha = 0.05
if p < alpha:
    print("\\nDecision: Reject H0 at alpha = 0.05.")
    print("Interpretation: evidence of a statistically significant linear association.")
else:
    print("\\nDecision: Fail to reject H0 at alpha = 0.05.")
    print("Interpretation: insufficient evidence of a linear association.")

# Scatter plot and fitted regression line
plt.figure(figsize=(8, 5))
plt.scatter(x, y, alpha=0.75, label="Students")
x_line = np.linspace(x.min(), x.max(), 100)
plt.plot(x_line, intercept + slope * x_line, label="Fitted regression line")
plt.xlabel("Study hours per day")
plt.ylabel("Exam score (out of 100)")
plt.title("Study Hours vs Exam Scores")
plt.legend()
plt.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("study_hours_exam_scores_scatter.png", dpi=180)
plt.show()

# Histogram
plt.figure(figsize=(8, 5))
plt.hist(y, bins=12, edgecolor="black")
plt.xlabel("Exam score (out of 100)")
plt.ylabel("Frequency")
plt.title("Distribution of Exam Scores")
plt.grid(axis="y", alpha=0.25)
plt.tight_layout()
plt.savefig("exam_score_histogram.png", dpi=180)
plt.show()
