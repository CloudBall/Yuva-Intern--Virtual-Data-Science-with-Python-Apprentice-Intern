# Week 2 — Advanced Data Visualization and Storytelling with Python

This project builds a coherent data story from the public Titanic passenger dataset. It includes six visualizations, a reproducible Jupyter notebook, a Python script, cleaned data (when generated), and a polished Word report.

## Dataset
Public CSV mirror: https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv  
The commonly used training file contains 891 passenger records and 12 columns. The notebook verifies the actual shape at runtime.

## Story sequence
1. Overall survival outcome — establishes the baseline.
2. Survival by sex — compares proportions rather than counts.
3. Survival by passenger class — reveals a class gradient.
4. Sex-by-class heatmap — explores a two-variable interaction.
5. Age distributions — compares age patterns while acknowledging imputation.
6. Family-size line plot — explores a derived feature and cautions about small groups.

## Run on Windows
```powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
jupyter notebook notebooks/Week2_Advanced_Visualization.ipynb
```
Run notebook cells from top to bottom. Internet is needed for first-time dataset acquisition. Alternatively, download the CSV from the source and save it as `data/titanic.csv`.

To run the script:
```powershell
python src/visualize_titanic.py
```

## Data decisions
The raw file is retained. Missing Age and Fare values are filled with their medians; missing Embarked values with its mode. FamilySize is calculated as SibSp + Parch + 1. These simple choices support descriptive visualizations but may affect distributions and should be reconsidered for inferential work.

## Key findings
The standard dataset has 342 survivors out of 891 passengers (about 38.4%). Observed survival rates are substantially higher among female passengers and first-class passengers than among male and third-class passengers. The sex-by-class heatmap provides a more nuanced view. These are associations, not proof of causation.

## Limitations
Historical, observational data; missing values; simple imputation; incomplete Cabin information; possible small group sizes; and potential changes to public data mirrors. Charts should be regenerated if the source dataset changes.
