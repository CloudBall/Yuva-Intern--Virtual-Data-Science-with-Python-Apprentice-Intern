"""Week 2: Advanced Data Visualization and Storytelling with Python."""
from pathlib import Path
import urllib.request
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
OUT_DIR = ROOT / "visualizations"
DATA_DIR.mkdir(exist_ok=True)
OUT_DIR.mkdir(exist_ok=True)
DATA_PATH = DATA_DIR / "titanic.csv"
DATA_URL = "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"

if not DATA_PATH.exists():
    urllib.request.urlretrieve(DATA_URL, DATA_PATH)

raw = pd.read_csv(DATA_PATH)
df = raw.copy()
df["Age"] = df["Age"].fillna(df["Age"].median())
df["Fare"] = df["Fare"].fillna(df["Fare"].median())
df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode().iloc[0])
df["FamilySize"] = df["SibSp"] + df["Parch"] + 1
df["SurvivalLabel"] = df["Survived"].map({0: "Did not survive", 1: "Survived"})

sns.set_theme(style="whitegrid", context="talk")
# 1. Overall outcome
fig, ax = plt.subplots(figsize=(8, 5))
sns.countplot(data=df, x="SurvivalLabel", order=["Did not survive", "Survived"], ax=ax)
ax.set(title="Most passengers did not survive", xlabel="", ylabel="Passenger count")
fig.tight_layout(); fig.savefig(OUT_DIR / "01_overall_survival.png", dpi=180); plt.close(fig)

# 2. Survival by sex
fig, ax = plt.subplots(figsize=(8, 5))
sns.barplot(data=df, x="Sex", y="Survived", order=["female", "male"], errorbar=None, ax=ax)
ax.set(title="Survival differed sharply by sex", xlabel="", ylabel="Survival rate")
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"{x:.0%}"))
fig.tight_layout(); fig.savefig(OUT_DIR / "02_survival_by_sex.png", dpi=180); plt.close(fig)

# 3. Survival by class
fig, ax = plt.subplots(figsize=(8, 5))
sns.barplot(data=df, x="Pclass", y="Survived", order=[1, 2, 3], errorbar=None, ax=ax)
ax.set(title="Observed survival declined across passenger classes", xlabel="Passenger class", ylabel="Survival rate")
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"{x:.0%}"))
fig.tight_layout(); fig.savefig(OUT_DIR / "03_survival_by_class.png", dpi=180); plt.close(fig)

# 4. Interaction heatmap
pivot = df.pivot_table(index="Sex", columns="Pclass", values="Survived", aggfunc="mean")
fig, ax = plt.subplots(figsize=(8, 5))
sns.heatmap(pivot, annot=True, fmt=".0%", vmin=0, vmax=1, cmap="YlGnBu", ax=ax)
ax.set(title="Sex and class together reveal different survival patterns", xlabel="Passenger class", ylabel="")
fig.tight_layout(); fig.savefig(OUT_DIR / "04_sex_class_heatmap.png", dpi=180); plt.close(fig)

# 5. Age distributions
fig, ax = plt.subplots(figsize=(8, 5))
sns.histplot(data=df, x="Age", hue="SurvivalLabel", bins=20, stat="count", common_norm=False, alpha=.45, ax=ax)
ax.set(title="Age distributions overlap", xlabel="Age (years)", ylabel="Passenger count")
fig.tight_layout(); fig.savefig(OUT_DIR / "05_age_distribution.png", dpi=180); plt.close(fig)

# 6. Family size
family = df.groupby("FamilySize", as_index=False)["Survived"].mean()
fig, ax = plt.subplots(figsize=(8, 5))
sns.lineplot(data=family[family["FamilySize"] <= 8], x="FamilySize", y="Survived", marker="o", ax=ax)
ax.set(title="Survival rates vary by family size", xlabel="Family size (passenger included)", ylabel="Survival rate")
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"{x:.0%}"))
fig.tight_layout(); fig.savefig(OUT_DIR / "06_family_size.png", dpi=180); plt.close(fig)
print(f"Created six visualizations in {OUT_DIR}")
