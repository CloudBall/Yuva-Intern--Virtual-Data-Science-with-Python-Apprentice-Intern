"""Reproducible Titanic data cleaning and EDA workflow."""
from pathlib import Path
import urllib.request
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
OUT_DIR = ROOT / "reports"
PLOT_DIR = ROOT / "visualizations"
DATA_DIR.mkdir(exist_ok=True); OUT_DIR.mkdir(exist_ok=True); PLOT_DIR.mkdir(exist_ok=True)
URL = "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"
raw_path = DATA_DIR / "titanic.csv"
if not raw_path.exists():
    urllib.request.urlretrieve(URL, raw_path)

raw = pd.read_csv(raw_path)
df = raw.copy()
df.columns = [c.strip() for c in df.columns]
dupes = int(df.duplicated().sum())
df = df.drop_duplicates().copy()
for col in ["Age", "Fare", "SibSp", "Parch", "Pclass", "Survived"]:
    if col in df: df[col] = pd.to_numeric(df[col], errors="coerce")
if "Age" in df: df["Age"] = df["Age"].fillna(df["Age"].median())
if "Fare" in df and df["Fare"].isna().any(): df["Fare"] = df["Fare"].fillna(df["Fare"].median())
if "Embarked" in df and df["Embarked"].isna().any(): df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode().iloc[0])
if "Cabin" in df: df = df.drop(columns=["Cabin"])
if {"SibSp","Parch"}.issubset(df.columns): df["FamilySize"] = df["SibSp"].fillna(0) + df["Parch"].fillna(0) + 1

sns.set_theme(style="whitegrid")
fig, ax = plt.subplots(figsize=(7,4))
sns.countplot(data=df, x="Survived", ax=ax)
ax.set_xticks([0,1], ["Did not survive","Survived"]); ax.set_title("Passenger survival outcome")
fig.tight_layout(); fig.savefig(PLOT_DIR/"survival_distribution.png", dpi=160); plt.close(fig)

for column, filename, title in [("Sex","survival_by_sex.png","Survival rate by sex"),("Pclass","survival_by_class.png","Survival rate by passenger class")]:
    rates = df.groupby(column, observed=False)["Survived"].mean()
    fig, ax = plt.subplots(figsize=(7,4)); rates.plot(kind="bar", ax=ax)
    ax.set_title(title); ax.set_ylabel("Survival rate"); ax.set_ylim(0,1); fig.tight_layout()
    fig.savefig(PLOT_DIR/filename, dpi=160); plt.close(fig)

fig, ax = plt.subplots(figsize=(7,4))
sns.histplot(data=df, x="Age", hue="Survived", bins=25, multiple="stack", ax=ax)
ax.set_title("Age distribution by survival outcome"); fig.tight_layout()
fig.savefig(PLOT_DIR/"age_distribution.png", dpi=160); plt.close(fig)

df.to_csv(OUT_DIR/"titanic_cleaned.csv", index=False)
df.groupby("Sex", observed=False)["Survived"].agg(["count","mean"]).to_csv(OUT_DIR/"survival_by_sex.csv")
df.groupby("Pclass", observed=False)["Survived"].agg(["count","mean"]).to_csv(OUT_DIR/"survival_by_class.csv")
print(f"Raw shape={raw.shape}; cleaned shape={df.shape}; exact duplicates removed={dupes}")
print(f"Survival rate={df['Survived'].mean():.1%}")
print("Outputs written to reports/ and visualizations/.")
