# Titanic Week 1 Project — Data Acquisition, Cleaning & EDA

A beginner-friendly, reproducible data-science project prepared for a Week 1 internship task.

## Objectives
- Acquire a public Titanic passenger dataset from a raw CSV source.
- Inspect schema, summary statistics, missing values and exact duplicate rows.
- Apply documented, defensible cleaning decisions using Pandas.
- Create visualizations for survival outcomes, survival by sex/class, age distribution, outliers and numeric correlations.
- Summarize findings and limitations without making causal claims.

## Dataset
- **Source CSV:** [https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv](https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv)
- **Mirror repository:** [DataScienceDojo datasets](https://github.com/datasciencedojo/datasets)
- The commonly used training file has 891 rows and 12 columns. The notebook checks the actual downloaded shape.
- `Survived`: 0 = did not survive, 1 = survived. `Pclass`: 1 = first class, 2 = second class, 3 = third class.

## Project structure
```text
Titanic_Week1_Project/
├── data/
│   └── .gitkeep                 # CSV downloads here when notebook/script runs
├── notebooks/
│   └── Titanic_Week1_EDA.ipynb
├── src/
│   └── eda_analysis.py
├── visualizations/
│   ├── survival_distribution.png
│   ├── survival_by_sex.png
│   ├── survival_by_class.png
│   └── missing_values.png
├── reports/
│   ├── Titanic_Week1_Report.docx
│   ├── submission_description.txt
│   └── README_REPORT.md
├── requirements.txt
├── .gitignore
└── README.md
```

## Run on Windows
1. Install Python 3.10+.
2. Extract this project ZIP and open a terminal in the project folder.
3. Create and activate an environment (recommended):
   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```
4. Install packages:
   ```powershell
   python -m pip install -r requirements.txt
   ```
5. Run the notebook:
   ```powershell
   jupyter notebook notebooks/Titanic_Week1_EDA.ipynb
   ```
   Run cells from top to bottom. Internet access is required for the first download. Alternatively, save the CSV manually as `data/titanic.csv`.
6. Or run the script:
   ```powershell
   python src/eda_analysis.py
   ```

## Main cleaning decisions
- Inspect exact duplicates before removing them.
- Impute missing Age with median; impute missing Fare only if needed.
- Impute missing Embarked with its mode.
- Remove Cabin from the analysis-ready table because it is highly sparse, while preserving the original raw CSV.
- Add FamilySize = SibSp + Parch + 1.
- Do not remove unusual Fare values automatically; investigate before deciding.

## Main findings (standard 891-row training file)
- 342/891 passengers survived (about 38.4%).
- Survival rate is much higher among female than male passengers.
- Survival rate decreases from first-class to third-class passengers.
- Age and Cabin contain missing data; Cabin is especially sparse.
These are descriptive patterns in this dataset, not proof of causality.

## Reproducibility and integrity
The notebook downloads the source CSV at runtime and regenerates the analysis from it. Charts bundled with the report are static summary charts based on the standard dataset's published counts/rates; rerun the notebook to regenerate charts from the downloaded CSV. Verify results if the source file changes. Do not claim a GitHub repository exists until you create it and push these files.

## Limitations and ethics
The dataset is historical and observational. Results may be confounded by multiple variables and should not be generalized to present-day populations. Imputation assumptions can affect findings. Do not use this exercise as a predictive or causal model without further validation.
