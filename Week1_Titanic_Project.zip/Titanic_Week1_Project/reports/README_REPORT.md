# Report companion files

- `Titanic_Week1_Report.docx`: formatted report for submission.
- `submission_description.txt`: copy the complete 200+ word description into the internship portal.
- `titanic_cleaned.csv` and group summary CSV files are generated when the notebook or script is run.
